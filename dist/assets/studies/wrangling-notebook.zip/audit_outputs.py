"""Audit supplied output files; does not claim to regenerate missing raw data."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
ROOT=Path.cwd() if (Path.cwd()/'data/Group097_dirty_data_solution.csv').exists() else Path(__file__).resolve().parent
results=[]
for p in sorted((ROOT/'data').glob('*solution.csv')):
    df=pd.read_csv(p);price=pd.to_numeric(df.order_price,errors='coerce');discount=pd.to_numeric(df.coupon_discount,errors='coerce');delivery=pd.to_numeric(df.delivery_charges,errors='coerce');total=pd.to_numeric(df.order_total,errors='coerce')
    expected=price*(1-discount/100)+delivery;valid=expected.notna()&total.notna();mismatch=(total[valid]-expected[valid]).abs()>.02
    seasons=pd.to_datetime(df.date,errors='coerce').dt.month.map({12:'Summer',1:'Summer',2:'Summer',3:'Autumn',4:'Autumn',5:'Autumn',6:'Winter',7:'Winter',8:'Winter',9:'Spring',10:'Spring',11:'Spring'})
    results.append({'dataset':p.name.replace('Group097_','').replace('_solution.csv',''),'rows':len(df),'missing_cells':int(df.isna().sum().sum()),'duplicate_order_ids':int(df.order_id.duplicated().sum()),'formula_check_rows':int(valid.sum()),'order_total_mismatches':int(mismatch.sum()),'formula_tolerance':.02,'season_mismatches':int((df.season.str.lower()!=seasons.str.lower()).sum()),'negative_delivery_charges':int((delivery<0).sum()),'unexpected_columns':list(df.columns[16:])})
out={'kind':'fresh audit of submitted cleaned outputs','scope':'arithmetic, missingness, order-ID uniqueness and Melbourne calendar seasons; not raw-data cleaning reproduction','results':results}
(ROOT/'outputs').mkdir(exist_ok=True);(ROOT/'outputs/wrangling-results.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
