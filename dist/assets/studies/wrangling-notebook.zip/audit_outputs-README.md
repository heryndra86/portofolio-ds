# Wrangling portfolio notebook

Original coursework files remain unchanged. This is a new, small portfolio edition with explicit evaluation scope. It is not a full rerun of every original notebook or model.

Run the notebook from the folder containing data/. The equivalent .py or .R source was executed successfully; its outputs are recorded in the notebook and JSON result file. Original data is not included in this download. Use the local project archive's data/ folder; the README does not imply this ZIP alone is a complete runnable dataset bundle.

Python environment for stock/NLP/audit: Python 3.9, pandas 2.2.3, numpy 2.0.2, scikit-learn 1.6.1. NLP also uses sklearn-crfsuite 0.5.0 and seqeval 1.2.2. Survey uses an R kernel, randomForest and jsonlite.

Input requirements:
- stock: data/stock/stock_data.csv and training_targets.csv
- NLP: data/nlp/train.txt
- audit: data/Group097_dirty_data_solution.csv, Group097_missing_data_solution.csv, Group097_outlier_data_solution.csv
- survey: data/regression_train.csv and classification_train.csv

Group NLP and retail coursework: individual task ownership is not reconstructed. Portfolio baseline/audit work is described separately from the original group work.

Validation limits: stock uses six chronological expanding month holdouts and a future-perturbation check; NLP uses one normalised-utterance-grouped holdout; the retail audit tests supplied outputs only and identifies unresolved inconsistencies; survey uses one fixed random split. No original advanced model performance is implied by these runs.
