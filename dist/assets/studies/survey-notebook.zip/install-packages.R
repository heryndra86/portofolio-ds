install.packages(c("randomForest", "jsonlite"), repos="https://cloud.r-project.org")
