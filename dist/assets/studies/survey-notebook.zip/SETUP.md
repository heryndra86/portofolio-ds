# Running this portfolio edition

Install R and run Rscript install-packages.R. Run Rscript survey_portfolio.R from this folder, or use an R notebook kernel.

The original input datasets are not included. The project README lists the required data/ paths. Do not treat the ZIP as a standalone reproduction bundle. Recover the authorised original data before running; no synthetic substitute has been used to recreate the published results.

Saved notebook outputs and JSON results remain available for inspection without execution. Dependency installation and model reruns were not repeated during the November 2026 interface update.
