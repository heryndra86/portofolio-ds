# Running this portfolio edition

Use Python 3.9. Create a virtual environment, activate it and run python -m pip install -r requirements.txt. Run the included .py script from this folder.

The original input datasets are not included. The project README lists the required data/ paths. Do not treat the ZIP as a standalone reproduction bundle. Recover the authorised original data before running; no synthetic substitute has been used to recreate the published results.

Saved notebook outputs and JSON results remain available for inspection without execution. Dependency installation and model reruns were not repeated during the November 2026 interface update.
